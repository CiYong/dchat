
#include "dchat_client_app.hpp"

#include <iostream>

namespace drift {

ChatClientApp::ChatClientApp(std::string address_, QObject *parent) : QObject(parent), _client(address_) {

    _account_id = "drifter_a";
}

ChatClientApp::~ChatClientApp() {

}

void ChatClientApp::setProperty(QString name, QString section, QString key, QString value) {

}

QString ChatClientApp::getProperty(QString name, QString section, QString key) {

    return {};
}

bool ChatClientApp::send_msg (QString contact_id, int type, bool is_read, QString content) {

    std::cout << "[ChatClientApp] send called." << std::endl;
    std::cout << "[ChatClientApp] contact_id=" << contact_id.toStdString() << std::endl;
    std::cout << "[ChatClientApp] type=" << type << std::endl;
    std::cout << "[ChatClientApp] is_read=" << is_read << std::endl;
    std::cout << "[ChatClientApp] content=" << content.toStdString() << std::endl;

    drift::Message msg{static_cast<MessageType>(type), is_read, content.toStdString()};

    auto result = _client.send_msg(_account_id, contact_id.toStdString(), msg);

    std::cout << "[ChatClientApp] reply=" << (result? "ok" : "ng") << std::endl;

    return true;
}

// Group send message.
bool ChatClientApp::send_group (std::string account_id, std::vector<std::string> contacts, std::vector<Message> messages) {

    return true;
}

// Pull unread message from server.
bool ChatClientApp::pull_message () {
    std::cout << "[ChatClientApp] pull_message called." << std::endl;
    auto result = _client.pull_message(_account_id);

    std::cout << "[ChatClientApp] pull_message called end." << std::endl;

    for (auto& msg : result) {
        std::cout << "[ChatClientApp] reply=" << msg.message.size() << std::endl;
        std::cout << "[ChatClientApp] reply=" << msg.contact_id << std::endl;
        std::cout << "[ChatClientApp] reply=" << ( msg.message.empty() ? msg.message[0].content : "msg is empty") << std::endl;
    }

    return true;
}

// Add new contact by contact id.
bool ChatClientApp::contact_add_new (std::string account_id, std::string contact_id) {

    return true;
}

// Delete contact by contact id.
bool ChatClientApp::contact_delete (std::string account_id, std::string contact_id) {

    return true;
}

// basic send message.
std::vector<Contact> ChatClientApp::contacts_load (std::string account_id) {

    return {};
}

// Update contact settings.
bool ChatClientApp::contact_update (std::string account_id, Contact contact)  {

    return true;
}

// Load account settings.
bool ChatClientApp::account_load () {
    std::cout << "[ChatClientApp] account_load called."  << std::endl;
    auto result = _client.account_load();

    std::cout << "[ChatClientApp] account_load called end." << std::endl;

    std::cout << "[ChatClientApp] accout.basic.id=" << result.basic.id << std::endl;

    return true;
}

// Update account settings.
bool ChatClientApp::account_update (Account account)  {

    return true;
}

// Establish connection for voice communication.
bool ChatClientApp::voice_call (std::string account_id, std::string contact_id)  {

    return true;
}

// Establish connection for video communication.
bool ChatClientApp::video_call (std::string account_id, std::string contact_id)  {

    return true;
}

}
