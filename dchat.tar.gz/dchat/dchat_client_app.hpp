/*
 *
 * Copyright 2021 drift chat authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */


#ifndef __drift_chat_client_hpp__
#define __drift_chat_client_hpp__

#include "dchat_client.hpp"
#include <QObject>

namespace drift {

class ChatClientApp : public QObject {
    Q_OBJECT
public:
    explicit ChatClientApp(std::string address_, QObject *parent = nullptr);
    ~ChatClientApp();

    Q_INVOKABLE void setProperty(QString name, QString section, QString key, QString value);
    Q_INVOKABLE QString getProperty(QString name, QString section, QString key);

    Q_INVOKABLE bool send_msg (QString contact_id, int type, bool is_read, QString content);

    // Group send message.
    Q_INVOKABLE bool send_group (std::string account_id, std::vector<std::string> contacts, std::vector<Message> messages);

    // Pull unread message from server.
    Q_INVOKABLE bool pull_message ();

    // Add new contact by contact id.
    virtual bool contact_add_new (std::string account_id, std::string contact_id);

    // Delete contact by contact id.
    virtual bool contact_delete (std::string account_id, std::string contact_id);

    // basic send message.
    virtual std::vector<Contact> contacts_load (std::string account_id);

    // Update contact settings.
    virtual bool contact_update (std::string account_id, Contact contact);

    // Load account settings.
    Q_INVOKABLE bool account_load ();

    // Update account settings.
    virtual bool account_update (Account account);

    // Establish connection for voice communication.
    virtual bool voice_call (std::string account_id, std::string contact_id);

    // Establish connection for video communication.
    virtual bool video_call (std::string account_id, std::string contact_id);

private:
    dchatClient _client;
    std::string _account_id;
};

} // namespace drift

#endif // __drift_chat_client_hpp__
