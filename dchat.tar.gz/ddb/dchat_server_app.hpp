/*
 *
 * Copyright 2021 drift server authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */


#ifndef __drift_chat_server_hpp__
#define __drift_chat_server_hpp__

#include "dchat_server.hpp"

namespace drift {

class ChatServer : public dchatServerIF {
public:
    // Basic send message.
    virtual bool send_msg (std::string account_id, std::string contact_id, Message messages);

    // Group send message.
    virtual bool send_group (std::string account_id, std::vector<std::string> contacts, std::vector<Message> messages);

    // Pull unread message from server.
    virtual std::vector<PullMessage> pull_message (std::string account_id);

    // Add new contact by contact id.
    virtual bool contact_add_new (std::string account_id, std::string contact_id);

    // Delete contact by contact id.
    virtual bool contact_delete (std::string account_id, std::string contact_id);

    // basic send message.
    virtual std::vector<Contact> contacts_load (std::string account_id);

    // Update contact settings.
    virtual bool contact_update (std::string account_id, Contact contact);

    // Load account settings.
    virtual Account account_load ();

    // Update account settings.
    virtual bool account_update (Account account);

    // Establish connection for voice communication.
    virtual bool voice_call (std::string account_id, std::string contact_id);

    // Establish connection for video communication.
    virtual bool video_call (std::string account_id, std::string contact_id);
};

} // namespace drift

#endif // __drift_chat_server_hpp__
