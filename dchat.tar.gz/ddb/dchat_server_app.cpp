
#include "dchat_server_app.hpp"

#include <iostream>

namespace drift {

// Basic send message.
bool ChatServer::send_msg (std::string account_id, std::string contact_id, Message messages) {

    std::cout << "[ChatServer] send received." << std::endl;
    std::cout << "[ChatServer] account_id=" << account_id << std::endl;
    std::cout << "[ChatServer] contact_id=" << contact_id << std::endl;
    std::cout << "[ChatServer] messages.type=" << static_cast<int>(messages.type) << std::endl;
    std::cout << "[ChatServer] messages.is_read=" << static_cast<int>(messages.is_read) << std::endl;
    std::cout << "[ChatServer] messages.content=" << messages.content << std::endl;

    return true;
}

// Group send message.
bool ChatServer::send_group (std::string account_id, std::vector<std::string> contacts, std::vector<Message> messages) {


    return true;
}

// Pull unread message from server.
std::vector<PullMessage> ChatServer::pull_message (std::string account_id) {
    std::cout << "[ChatServer] pull_message received." << std::endl;
    std::cout << "[ChatServer] account_id=" << account_id << std::endl;

    std::vector<PullMessage> messages;

    PullMessage msg{"drifter_a", {Message{MessageType::text, false, "hello drifter_a"},
                                  Message{MessageType::text, false, "hello drifter_b"},
                                  Message{MessageType::text, false, "hello drifter_c"}}};

    messages.emplace_back(std::move(msg));

    return messages;
}

// Add new contact by contact id.
bool ChatServer::contact_add_new (std::string account_id, std::string contact_id) {

    return true;
}

// Delete contact by contact id.
bool ChatServer::contact_delete (std::string account_id, std::string contact_id) {

    return true;
}

// basic send message.
std::vector<Contact> ChatServer::contacts_load (std::string account_id) {

    return {};
}

// Update contact settings.
bool ChatServer::contact_update (std::string account_id, Contact contact)  {

    return true;
}

// Load account settings.
Account ChatServer::account_load () {
    std::cout << "[ChatServer] account_load received." << std::endl;

    AccountBasicInfo basic_info;
    basic_info.id = "drifter_server";
    Account account;
    account.basic = basic_info;

    return account;
}

// Update account settings.
bool ChatServer::account_update (Account account)  {

    return true;
}

// Establish connection for voice communication.
bool ChatServer::voice_call (std::string account_id, std::string contact_id)  {

    return true;
}

// Establish connection for video communication.
bool ChatServer::video_call (std::string account_id, std::string contact_id)  {

    return true;
}

}
